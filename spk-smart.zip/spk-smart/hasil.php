<?php include 'auth.php'; ?>
<?php include "header.php"; ?>
<?php
include "config/database.php";

// Tangani penghapusan satu data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $conn->query("DELETE FROM hasil WHERE id_alternatif = '$id'");
    header("Location: hasil.php");
    exit();
}

// Tangani hapus semua
if (isset($_GET['hapus_semua']) && $_GET['hapus_semua'] == 'true') {
    $conn->query("TRUNCATE TABLE hasil");
    header("Location: hasil.php");
    exit();
}

// Filter tanggal
$tanggalFilter = $_GET['tanggal'] ?? '';
$where = $tanggalFilter ? "WHERE DATE(h.waktu) = '$tanggalFilter'" : "";

// Ambil data hasil + alternatif
$sql = "
    SELECT a.nama_alternatif, h.id_alternatif, h.skor_akhir, h.waktu
    FROM hasil h 
    JOIN alternatif a ON h.id_alternatif = a.id_alternatif
    $where
    ORDER BY h.skor_akhir DESC
";
$query = $conn->query($sql);

if (!$query) {
    die("Query error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Hasil Peringkat</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <style>
        h3 {
            margin-top: 20px;
            text-align: center;
            color:rgb(0, 0, 0);
        }

        table {
            margin-top: 30px;
        }

        th,
        td {
            text-align: center;
        }

        .rank {
            font-weight: bold;
            background-color: #f8f9fa;
        }
    </style>
</head>

<body>
    <div class="container">
        <h3>Hasil Peringkat Alternatif</h3>
        <div class="d-flex justify-content-between align-items-center my-3">
            <form method="GET" class="d-flex align-items-center">
                <a href="hasil.php?hapus_semua=true" class="btn btn-danger btn-sm"
                    onclick="return confirm('Yakin ingin menghapus semua hasil?')">
                    Hapus Semua Hasil
                </a>
            </form>
        </div>

        <table class="table table-bordered mt-4">
            <thead class="table-primary">
                <tr>
                    <th>Peringkat</th>
                    <th>Alternatif</th>
                    <th>Skor (%)</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $rank = 1;
                while ($row = $query->fetch_assoc()):
                    $skor_persen = $row['skor_akhir'] * 100;
                    $warna = $rank == 1 ? 'bg-success' : ($rank == 2 ? 'bg-info' : ($rank == 3 ? 'bg-warning' : 'bg-secondary'));
                ?>
                    <tr>
                        <td class="rank"><?= $rank++ ?></td>
                        <td><?= $row['nama_alternatif'] ?></td>
                        <td><?= number_format($skor_persen, 2) ?>%</td>
                        <td>
                            <a href="hasil.php?hapus=<?= $row['id_alternatif'] ?>" class="btn btn-sm btn-danger"
                                onclick="return confirm('Hapus hasil ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile ?>
            </tbody>
        </table>
    </div>
</body>

</html>