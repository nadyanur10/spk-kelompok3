<?php include 'auth.php'; ?>

<?php include "header.php"; ?>

<?php
include "config/database.php";

$hasil = [];
$detail = [];

if (isset($_POST['hitung'])) {
    $conn->query("TRUNCATE TABLE hasil");

    // Ambil semua alternatif
    $alternatif = $conn->query("SELECT * FROM alternatif");

    // Ambil data kriteria
    $kriteria = [];
    $total_bobot = 0;
    $queryKriteria = $conn->query("SELECT * FROM kriteria");
    while ($row = $queryKriteria->fetch_assoc()) {
        $kriteria[$row['id_kriteria']] = [
            'nama' => $row['nama_kriteria'],
            'bobot' => $row['bobot'],
            'tipe' => $row['tipe']
        ];
        $total_bobot += $row['bobot'];
    }

    // Hitung bobot proporsional
    foreach ($kriteria as $id => $data) {
        $kriteria[$id]['bobot_proporsional'] = $data['bobot'] / $total_bobot;
    }
    // Ambil data nilai dan normalisasi
    $normalisasi = [];
    $nilai_kriteria = [];

    foreach ($kriteria as $id_kriteria => $data) {
        $tipe = $data['tipe'];

        // Ambil nilai max atau min berdasarkan tipe
        $queryMaxMin = $conn->query("SELECT " . ($tipe == 'cost' ? 'MIN' : 'MAX') . "(nilai) as val FROM nilai WHERE id_kriteria = '$id_kriteria'");
        $pembagi = $queryMaxMin->fetch_assoc()['val'];

        // Ambil semua nilai untuk kriteria ini
        $queryNilai = $conn->query("SELECT * FROM nilai WHERE id_kriteria = '$id_kriteria'");
        while ($n = $queryNilai->fetch_assoc()) {
            $id_alt = $n['id_alternatif'];
            $nilai_asli = $n['nilai'];

            $nilai_norm = ($tipe == 'cost') ? $pembagi / $nilai_asli : $nilai_asli / $pembagi;

            $normalisasi[$id_alt][$id_kriteria] = $nilai_norm;
            $nilai_kriteria[$id_alt][$id_kriteria] = $nilai_asli;
        }
    }

    // Hitung skor akhir
    $skor_max = 0; // Maksimal skor
    foreach ($normalisasi as $id_alt => $nilai) {
        $total = 0;
        foreach ($nilai as $id_krit => $val_norm) {
            $total += $val_norm * $kriteria[$id_krit]['bobot_proporsional'];
        }

        // Simpan skor_max untuk normalisasi
        if ($total > $skor_max) {
            $skor_max = $total;
        }
        // Simpan ke DB dan array
        $conn->query("INSERT INTO hasil (id_alternatif, skor_akhir) VALUES ('$id_alt', '$total')");
        $nama_alt = $conn->query("SELECT nama_alternatif FROM alternatif WHERE id_alternatif='$id_alt'")->fetch_assoc()['nama_alternatif'];
        $hasil[] = ['id' => $id_alt, 'nama' => $nama_alt, 'skor' => $total];
    }

    // Normalisasi skor akhir untuk skala 0-1
    foreach ($hasil as &$row) {
        $row['skor_normalisasi'] = $row['skor'] / $skor_max; // Normalisasi skor
    }

    // Cari skor maksimal
    $skor_max = max(array_column($hasil, 'skor'));

    // Tambahkan skor normalisasi
    foreach ($hasil as &$row) {
        $row['skor_normalisasi'] = $row['skor'] / $skor_max;
    }


    // Urutkan berdasarkan skor
    usort($hasil, function ($a, $b) {
        return $b['skor_normalisasi'] <=> $a['skor_normalisasi'];
    });

    // Siapkan detail untuk ditampilkan
    $detail = ['kriteria' => $kriteria, 'normalisasi' => $normalisasi, 'nilai_asli' => $nilai_kriteria];
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Perhitungan SMART</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container mt-4">
        <h3 class="text-center">Proses Perhitungan Metode SMART</h3>
        <form method="post" class="text-center mt-3 mb-4">
            <button type="submit" name="hitung" class="btn btn-success">Mulai Perhitungan</button>
        </form>

        <?php if (!empty($hasil)) : ?>
            <h5>Bobot Proporsional</h5>
            <table class="table table-bordered">
                <tr>
                    <th>Kriteria</th>
                    <th>Tipe</th>
                    <th>Bobot Asli</th>
                    <th>Bobot Proporsional</th>
                </tr>
                <?php foreach ($detail['kriteria'] as $krit): ?>
                    <tr>
                        <td><?= $krit['nama'] ?></td>
                        <td><?= ucfirst($krit['tipe']) ?></td>
                        <td><?= $krit['bobot'] ?></td>
                        <td><?= number_format($krit['bobot_proporsional'], 4) ?></td>
                    </tr>
                <?php endforeach ?>
            </table>

            <h5>Normalisasi Nilai</h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Alternatif</th>
                        <?php foreach ($detail['kriteria'] as $krit): ?>
                            <th><?= $krit['nama'] ?></th>
                        <?php endforeach ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($detail['normalisasi'] as $id_alt => $nilai): ?>
                        <tr>
                            <td><?= $conn->query("SELECT nama_alternatif FROM alternatif WHERE id_alternatif='$id_alt'")->fetch_assoc()['nama_alternatif'] ?></td>
                            <?php foreach ($detail['kriteria'] as $id_krit => $_): ?>
                                <td><?= number_format($nilai[$id_krit], 4) ?></td>
                            <?php endforeach ?>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>

            <h5>Skor Akhir</h5>
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Alternatif</th>
                        <th>Skor Akhir</th>
                        <th>skor normalisasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($hasil as $row): ?>
                        <tr>
                            <td><?= $row['nama'] ?></td>
                            <td><?= number_format($row['skor'], 4)?></td>
                            <td><?= number_format($row['skor_normalisasi'], 6) ?></td> <!-- Skor dinormalisasi -->
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>

        <?php endif ?>
    </div>
</body>

</html>