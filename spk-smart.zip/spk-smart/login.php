<?php
session_start();

// Jika tombol masuk ditekan
if (isset($_POST['masuk'])) {
    $_SESSION['login'] = true; // Set login session
    header("Location: input_alternatif.php"); // Redirect ke beranda
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Login SPK</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
<style>
    .content {
        margin-top: 20px;
        text-align: center;
    }

    .btn-start {
        margin-top: 20px;
        background-color: #007bff;
        color: white;
        padding: 10px 20px;
        font-size: 1.2rem;
        border: none;
    }

    .btn-start:hover {
        background-color: #0056b3;
    }

    .spk {
        margin-top: 100px;
        font-size: 40px;
        color: #0056b3;
        font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    }

    .spks {
        color: #0056b3;
        font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    }

    .spkss {
        color: black;
        font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    }
</style>
</head>

<body>
    <!-- Content -->
    <div>
        <div class="mb-9">
            <div class="container content">
                <h1 class="spk">SELAMAT DATANG DI SISTEM PENDUKUNG KEPUTUSAN</h1>
                <h1 class="spks">MENENTUKAN ALTERNATIF TERBAIK DENGAN METODE SMART</h1>

                <br>
                <div class="container mt-5">
                    <h2 class="spkss">Mulai Menghitung Hasil Peringkat Alternatif</h2>
                    <p class="sp">Gunakan sistem ini untuk menghitung peringkat alternatif berdasarkan kriteria yang telah ditentukan.</p>
                    <form method="post">
                        <button type="submit" name="masuk" class="btn btn-success mt-4">Mulai Menghitung</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php include "footer.php"; ?>
</body>

</html>