<?php include 'auth.php'; ?>

<?php
$host = "localhost";
$user = "root";
$pass = ""; // default password XAMPP
$db   = "spk_smart";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
