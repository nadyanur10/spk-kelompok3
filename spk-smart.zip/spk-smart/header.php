<!DOCTYPE html>
<html>

<head>
  <title>SPK SMART</title>
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Optional Styling -->
  <style>
    body {
      padding-top: 70px;
      background-color: #f9f9f9;
    }

    .container {
      margin-top: 30px;
    }

    .table th {
      background-color: #f0f0f0;
    }
  </style>
</head>

<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">SPK SMART</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item"><a class="nav-link" href="input_alternatif.php">Alternatif</a></li>
          <li class="nav-item"><a class="nav-link" href="input_kriteria.php">Kriteria</a></li>
          <li class="nav-item"><a class="nav-link" href="input_nilai.php">Nilai</a></li>
          <li class="nav-item"><a class="nav-link" href="proses.php">Proses</a></li>
          <li class="nav-item"><a class="nav-link" href="hasil.php">Hasil</a></li>
          <?php if (isset($_SESSION['login'])): ?>
            <li class="nav-item"><a class="nav-link" href="logout.php">Keluar</a></li>
          <?php endif; ?>


        </ul>
      </div>
    </div>
  </nav>