<?php include 'auth.php'; ?>

<?php include "config/database.php"; ?>
<?php include "header.php"; ?>

<div class="container">
    <h2 class="text-center mb-4">Input Alternatif</h2>

    <?php
    // Simpan data
    if (isset($_POST['simpan'])) {
        $nama = $_POST['nama_alternatif'];
        $conn->query("INSERT INTO alternatif (nama_alternatif) VALUES ('$nama')");
        echo '<div class="alert alert-success mt-3">Data berhasil disimpan.</div>';
    }

    // Hapus data satu per satu
    if (isset($_GET['hapus'])) {
        $id = $_GET['hapus'];
        $conn->query("DELETE FROM alternatif WHERE id_alternatif='$id'");

        // Periksa apakah data terhapus
        if ($conn->affected_rows > 0) {
            echo '<div class="alert alert-danger mt-3">Data berhasil dihapus.</div>';
        } else {
            echo '<div class="alert alert-warning mt-3">Data gagal dihapus.</div>';
        }
    }

    // Edit data
    if (isset($_GET['edit'])) {
        $id = $_GET['edit'];
        $edit = $conn->query("SELECT * FROM alternatif WHERE id_alternatif='$id'")->fetch_assoc();
    }

    // Update data
    if (isset($_POST['update'])) {
        $id = $_POST['id_alternatif'];
        $nama = $_POST['nama_alternatif'];
        $conn->query("UPDATE alternatif SET nama_alternatif='$nama' WHERE id_alternatif='$id'");
        echo '<div class="alert alert-info mt-3">Data berhasil diperbarui.</div>';
    }

    // Tangani hapus semua
    if (isset($_GET['hapus_semua']) && $_GET['hapus_semua'] == 'true') {
        $conn->query("DELETE FROM alternatif");

        // Redirect setelah hapus semua
        header("Location: input_alternatif.php");
        exit();
    }
    ?>

<!DOCTYPE html>
<html>
<head>
    <title>Perhitungan SMART</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <form method="post" class="mb-4">
        <div class="mb-3">
            <label class="form-label">Nama Alternatif</label>
            <input type="text" name="nama_alternatif" class="form-control" required
                value="<?= isset($edit) ? $edit['nama_alternatif'] : '' ?>">
        </div>
        <?php if (isset($edit)) { ?>
            <input type="hidden" name="id_alternatif" value="<?= $edit['id_alternatif'] ?>">
            <button type="submit" name="update" class="btn btn-warning">Update</button>
            <a href="input_alternatif.php" class="btn btn-secondary">Batal</a>
        <?php } else { ?>
            <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
        <?php } ?>
    </form>

    <h4>Daftar Alternatif</h4>
    <div class="d-flex justify-content-between align-items-center my-3">
        <form method="GET" class="d-flex align-items-center">
            <a href="input_kriteria.php?hapus_semua=true" class="btn btn-danger btn-sm"
                onclick="return confirm('Yakin ingin menghapus semua imput kriteria?')">
                Hapus Semua Kriteria
            </a>
        </form>
    </div>
    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>No</th>
                <th>Nama Alternatif</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $data = $conn->query("SELECT * FROM alternatif");
            while ($row = $data->fetch_assoc()) {
                echo "<tr>
                        <td>{$no}</td>
                        <td>{$row['nama_alternatif']}</td>
                        <td>
                            <a href='?edit={$row['id_alternatif']}' class='btn btn-sm btn-warning'>Edit</a>
                            <a href='?hapus={$row['id_alternatif']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Yakin ingin hapus?\")'>Hapus</a>
                        </td>
                    </tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
</div>
<?php include "footer.php"; ?>
</body>
</html>
