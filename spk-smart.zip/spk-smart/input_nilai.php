<?php include 'auth.php'; ?>

<?php include "config/database.php"; ?>
<?php include "header.php"; ?>

<div class="container">
    <h2 class="text-center mb-4">Input Nilai</h2>

    <?php
    // Simpan data
    if (isset($_POST['simpan'])) {
        $id_alternatif = $_POST['id_alternatif'];
        $id_kriteria = $_POST['id_kriteria'];
        $nilai = $_POST['nilai'];
        $conn->query("INSERT INTO nilai (id_alternatif, id_kriteria, nilai) VALUES ('$id_alternatif', '$id_kriteria', '$nilai')");
        echo '<div class="alert alert-success mt-3">Data berhasil disimpan.</div>';
    }

    // Hapus data
    if (isset($_GET['hapus'])) {
        $id = $_GET['hapus'];
        $conn->query("DELETE FROM nilai WHERE id_nilai='$id'");
        echo '<div class="alert alert-danger mt-3">Data berhasil dihapus.</div>';
    }

    // Edit data
    if (isset($_GET['edit'])) {
        $id = $_GET['edit'];
        $edit = $conn->query("SELECT * FROM nilai WHERE id_nilai='$id'")->fetch_assoc();
        $id_alternatif = $edit['id_alternatif'];
        $id_kriteria = $edit['id_kriteria'];
        $nilai = $edit['nilai'];
    }

    // Update data
    if (isset($_POST['update'])) {
        $id = $_POST['id_nilai'];
        $id_alternatif = $_POST['id_alternatif'];
        $id_kriteria = $_POST['id_kriteria'];
        $nilai = $_POST['nilai'];
        $conn->query("UPDATE nilai SET id_alternatif='$id_alternatif', id_kriteria='$id_kriteria', nilai='$nilai' WHERE id_nilai='$id'");
        echo '<div class="alert alert-info mt-3">Data berhasil diperbarui.</div>';
    }

    // Tangani hapus semua
    if (isset($_GET['hapus_semua']) && $_GET['hapus_semua'] == 'true') {
        $conn->query("TRUNCATE TABLE nilai");
        header("Location: input_nilai.php");
        exit();
    }
    ?>

<!DOCTYPE html>
<html>

<head>
    <title>Perhitungan SMART</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <form method="post" class="mb-4">
        <div class="mb-3">
            <label class="form-label">Alternatif</label>
            <select name="id_alternatif" class="form-select" required>
                <option value="">Pilih Alternatif</option>
                <?php
                $alternatif = $conn->query("SELECT * FROM alternatif");
                while ($row = $alternatif->fetch_assoc()) {
                    echo "<option value='{$row['id_alternatif']}'" . ($row['id_alternatif'] == $id_alternatif ? ' selected' : '') . ">{$row['nama_alternatif']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Kriteria</label>
            <select name="id_kriteria" class="form-select" required>
                <option value="">Pilih Kriteria</option>
                <?php
                $kriteria = $conn->query("SELECT * FROM kriteria");
                while ($row = $kriteria->fetch_assoc()) {
                    echo "<option value='{$row['id_kriteria']}'" . ($row['id_kriteria'] == $id_kriteria ? ' selected' : '') . ">{$row['nama_kriteria']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Nilai</label>
            <input type="number" name="nilai" class="form-control" required value="<?= $nilai ?>">
        </div>
        <?php if (isset($edit)) { ?>
            <input type="hidden" name="id_nilai" value="<?= $edit['id_nilai'] ?>">
            <button type="submit" name="update" class="btn btn-warning">Update</button>
            <a href="input_nilai.php" class="btn btn-secondary">Batal</a>
        <?php } else { ?>
            <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
        <?php } ?>
    </form>

    <h4>Daftar Nilai</h4>
    <div class="d-flex justify-content-between align-items-center my-3">
        <form method="GET" class="d-flex align-items-center">
            <a href="input_nilai.php?hapus_semua=true" class="btn btn-danger btn-sm"
                onclick="return confirm('Yakin ingin menghapus semua imput nilai?')">
                Hapus Semua Nilai
            </a>
        </form>
    </div>
    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>No</th>
                <th>Alternatif</th>
                <th>Kriteria</th>
                <th>Nilai</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $data = $conn->query("SELECT nilai.*, alternatif.nama_alternatif, kriteria.nama_kriteria
                                  FROM nilai
                                  JOIN alternatif ON nilai.id_alternatif = alternatif.id_alternatif
                                  JOIN kriteria ON nilai.id_kriteria = kriteria.id_kriteria");
            while ($row = $data->fetch_assoc()) {
                echo "<tr>
                        <td>{$no}</td>
                        <td>{$row['nama_alternatif']}</td>
                        <td>{$row['nama_kriteria']}</td>
                        <td>{$row['nilai']}</td>
                        <td>
                            <a href='?edit={$row['id_nilai']}' class='btn btn-sm btn-warning'>Edit</a>
                            <a href='?hapus={$row['id_nilai']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Yakin ingin hapus?\")'>Hapus</a>
                        </td>
                    </tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
</div>

<?php include "footer.php"; ?>

</body>

</html>